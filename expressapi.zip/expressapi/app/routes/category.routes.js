module.exports = (app) => {
    const category = require('../controllers/category.controller.js');

    // Create a new category
    app.post('/category', category.create);

    // Retrieve all category
    app.get('/category', category.findAll);

    // Retrieve a single category with categoryId
    app.get('/category/:categoryId', category.findOne);

    // Update a Note with noteId
    app.put('/category/:categoryId', category.update);

    // Delete a Note with noteId
    app.delete('/category/:categoryId', category.delete);
	
	
}	