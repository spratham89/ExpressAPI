module.exports = (app) => {
    const subcategory = require('../controllers/subcategory.controller.js');

    // Create a new Sub category
    app.post('/subcategory', subcategory.create);

    // Retrieve all category
    app.get('/subcategory', subcategory.findAll);

    // Retrieve a single sub category with subcategoryId
    app.get('/subcategory/:subcategoryId', subcategory.findOne);

    // Update a sub category with subcategoryId
    app.put('/subcategory/:subcategoryId', subcategory.update);

    // Delete a Note with noteId
    app.delete('/subcategory/:subcategoryId', subcategory.delete);
	
	
}	