module.exports = (app) => {
    const products = require('../controllers/products.controller.js');

    // Create a new Sub category
    app.post('/products', products.create);

    // Retrieve all category
    app.get('/products', products.findAll);

    // Retrieve a single product with subcategoryId
    app.get('/products/:productId', products.findOne);

    // Update a sub category with subcategoryId
    app.put('/products/:productId', products.update);

    // Delete a Note with noteId
    app.delete('/products/:productId', products.delete);
	
	
}	