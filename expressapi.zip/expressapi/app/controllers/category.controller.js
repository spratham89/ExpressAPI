const Category = require('../models/category.model.js');
const Subcategory = require('../models/subcategory.model.js');

// Create and Save a new Category
exports.create = (req, res) => {
    // Validate request
	if(!req.body.category_name) {
        return res.status(400).send({
            message: "Category  can not be empty"
        });
    }

    // Create a Category
    const category = new Category({
        category_name: req.body.category_name || "Untitled Category", 
    });

    // Save Category in the database
    category.save()
    .then(data => {
        res.send(data);
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while creating the Category."
        });
    });
};
// Retrieve and return all Category from the database.
exports.findAll = (req, res) => {
    Category.find()
    .then(category => {
        res.send(category);
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while retrieving categories."
        });
    });
};
// Find a single categories with a categoryId
exports.findOne = (req, res) => {
    Category.findById(req.params.categoryId)
    .then(category => {
        if(!category) {
            return res.status(404).send({
                message: "Category found with id " + req.params.categoryId
            });            
        }
        res.send(category);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).send({
                message: "Category not found with id " + req.params.categoryId
            });                
        }
        return res.status(500).send({
            message: "Error retrieving Category with id " + req.params.categoryId
        });
    });
};
// Update a category identified by the categoryId in the request
exports.update = (req, res) => {
    // Validate Request
    if(!req.body.category_name) {
        return res.status(400).send({
            message: "Category can not be empty"
        });
    }

    // Find category and update it with the request body
    category.findByIdAndUpdate(req.params.categoryId, {
        category_name: req.body.category_name || "Untitled Category"
     
    }, {new: true})
    .then(category => {
        if(!category) {
            return res.status(404).send({
                message: "Category not found with id " + req.params.categoryId
            });
        }
        res.send(category);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).send({
                message: "Category not found with id " + req.params.categoryId
            });                
        }
        return res.status(500).send({
            message: "Error updating Category with id " + req.params.categoryId
        });
    });
};
// Delete a note with the specified categoryId in the request
exports.delete = (req, res) => {
    category.findByIdAndRemove(req.params.categoryId)
    .then(category => {
        if(!category) {
            return res.status(404).send({
                message: "Category not found with id " + req.params.categoryId
            });
        }
        res.send({message: "Category deleted successfully!"});
    }).catch(err => {
        if(err.kind === 'ObjectId' || err.name === 'NotFound') {
            return res.status(404).send({
                message: "Category not found with id " + req.params.categoryId
            });                
        }
        return res.status(500).send({
            message: "Could not delete Category with id " + req.params.categoryId
        });
    });
};

