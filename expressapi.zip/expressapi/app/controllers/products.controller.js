const Products = require('../models/products.model.js');
// Create and Save a new Category
exports.create = (req, res) => {
    // Validate request
	if(!req.body.product_name) {
        return res.status(400).send({
            message: "Product can not be empty"
        });
    }
	if(!req.body.price) {
        return res.status(400).send({
            message: "Price can not be empty"
        });
    }
	if(!req.body.categoryId) {
        return res.status(400).send({
            message: "Category  can not be empty"
        });
    }
    // Create a Product
    const products = new Products({
        product_name: req.body.product_name || "Untitled Product", 
		price: req.body.price || "Untitled Product Price", 
		 
		subcategoryId: req.body.subcategoryId || "Untitled Category ID", 
    });

    // Save Category in the database
    products.save()
    .then(data => {
        res.send(data);
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while creating the Category."
        });
    });
};
// Retrieve and return all Category from the database.
exports.findAll = (req, res) => {
    Products.find().populate("subcategoryId")
	.then(category => {
        res.send(category);
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while retrieving products."
        });
    });
};
// Find a single categories with a productId
exports.findOne = (req, res) => {
    Products.findById(req.params.productId)
    .then(products => {
        if(!products) {
            return res.status(404).send({
                message: "Products  found with id " + req.params.productId
            });            
        }
        res.send(products);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).send({
                message: "Products not found with id " + req.params.productId
            });                
        }
        return res.status(500).send({
            message: "Error retrieving Products with id " + req.params.products
        });
    });
};
// Update a category identified by the products in the request
exports.update = (req, res) => {
    // Validate Request
    if(!req.body.product_name) {
        return res.status(400).send({
            message: "Product can not be empty"
        });
    }
	if(!req.body.price) {
        return res.status(400).send({
            message: "Price can not be empty"
        });
    }
    // Find products and update it with the request body
    Products.findByIdAndUpdate(req.params.productId, {
        product_name: req.body.product_name || "Untitled Product",
		subcategoryId: req.body.subcategoryId || "Untitled Subcategory",
		price: req.body.price || "Untitled Price"
    }, {new: true})
    .then(products => {
        if(!products) {
            return res.status(404).send({
                message: "Product updated with id " + req.params.productId
            });
        }
        res.send(products);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).send({
                message: "Product not found with id " + req.params.productId
            });                
        }
        return res.status(500).send({
            message: "Error updating Product with id " + req.params.productId
        });
    });
};
// Delete a note with the specified productId in the request
exports.delete = (req, res) => {
    Products.findByIdAndRemove(req.params.productId)
    .then(products => {
        if(!products) {
            return res.status(404).send({
                message: "Product not found with id " + req.params.productId
            });
        }
        res.send({message: "Product deleted successfully!"});
    }).catch(err => {
        if(err.kind === 'ObjectId' || err.name === 'NotFound') {
            return res.status(404).send({
                message: "Product not found with id " + req.params.productId
            });                
        }
        return res.status(500).send({
            message: "Could not delete Product with id " + req.params.products
        });
    });
};