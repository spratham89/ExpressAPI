const Subcategory = require('../models/subcategory.model.js');

// Create and Save a new Category
exports.create = (req, res) => {
    // Validate request
	if(!req.body.subcategory_name) {
        return res.status(400).send({
            message: "Sub Category  can not be empty"
        });
    }
	if(!req.body.categoryId) {
        return res.status(400).send({
            message: "Sub Category  can not be empty"
        });
    }
    // Create a Sub Category
    const subcategory = new Subcategory({
        subcategory_name: req.body.subcategory_name || "Untitled Sub Category", 
		categoryId: req.body.categoryId || "Untitled  Category ID", 
    });

    // Save Category in the database
    subcategory.save()
    .then(data => {
        res.send(data);
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while creating the Category."
        });
    });
};
// Retrieve and return all Category from the database.
exports.findAll = (req, res) => {
    Subcategory.find().populate("categoryId")
    .then(category => {
        res.send(category);
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while retrieving categories."
        });
    });
};
// Find a single categories with a categoryId
exports.findOne = (req, res) => {
    Subcategory.findById(req.params.subcategoryId)
    .then(category => {
        if(!category) {
            return res.status(404).send({
                message: "Sub Category  found with id " + req.params.categoryId
            });            
        }
        res.send(category);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).send({
                message: "Sub Category not found with id " + req.params.categoryId
            });                
        }
        return res.status(500).send({
            message: "Error retrieving Category with id " + req.params.categoryId
        });
    });
};
// Update a category identified by the categoryId in the request
exports.update = (req, res) => {
    // Validate Request
    if(!req.body.subcategory_name) {
        return res.status(400).send({
            message: "Sub Category can not be empty"
        });
    }
	if(!req.body.categoryId) {
        return res.status(400).send({
            message: "Category can not be empty"
        });
    }
    // Find category and update it with the request body
    Subcategory.findByIdAndUpdate(req.params.subcategoryId, {
        subcategory_name: req.body.subcategory_name || "Untitled Sub Category",
		categoryId: req.body.categoryId || "Untitled Category ID"
     
    }, {new: true})
    .then(category => {
        if(!category) {
            return res.status(404).send({
                message: "Sub Category not found with id " + req.params.subcategoryId
            });
        }
        res.send(category);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).send({
                message: "Category not found with id " + req.params.subcategoryId
            });                
        }
        return res.status(500).send({
            message: "Error updating Category with id " + req.params.subcategoryId
        });
    });
};
// Delete a note with the specified subcategoryId in the request
exports.delete = (req, res) => {
    Subcategory.findByIdAndRemove(req.params.subcategoryId)
    .then(category => {
        if(!category) {
            return res.status(404).send({
                message: "Sub Category not found with id " + req.params.subcategoryId
            });
        }
        res.send({message: "Sub Category deleted successfully!"});
    }).catch(err => {
        if(err.kind === 'ObjectId' || err.name === 'NotFound') {
            return res.status(404).send({
                message: "Sub Category not found with id " + req.params.subcategoryId
            });                
        }
        return res.status(500).send({
            message: "Could not delete Sub Category with id " + req.params.subcategoryId
        });
    });
};