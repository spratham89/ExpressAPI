const mongoose = require('mongoose');
var Schema = mongoose.Schema;
const SubcategorySchema = mongoose.Schema({
    subcategory_name: String,
	categoryId:  String,
	subcategoryId: String
}, {
    timestamps: true
});

module.exports = mongoose.model('Subcategory', SubcategorySchema);