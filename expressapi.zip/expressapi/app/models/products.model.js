const mongoose = require('mongoose');
var Schema = mongoose.Schema;

const ProductsSchema = mongoose.Schema({
    product_name: String,
	price: Number,
	subcategoryId: {
		type: Schema.Types.ObjectId,
		ref: "Subcategory"
	},
		
}, {
    timestamps: true
});

module.exports = mongoose.model('Products', ProductsSchema);